---  
name: Feature / Task Request  
about: Create a new feature or development task  
title: '[TASK] ระบบจัดการสินค้า หมวดหมู่ และแบนเนอร์ (Product, Category, and Banner Management)'  
labels: 'enhancement'  
assignees: ''  
---  

## User Story  
**As an** Admin  
**I want to** สามารถเพิ่มสินค้าใหม่, แก้ไขราคา, เพิ่ม/ลดสต็อกสินค้า, จัดการหมวดหมู่ และจัดการแบนเนอร์ของระบบได้  
**So that** เพื่อให้ข้อมูลสินค้ามีความเป็นปัจจุบัน ถูกต้อง และสามารถปรับแต่งหน้าเว็บหรือโปรโมชันผ่านแบนเนอร์ได้ตามต้องการ  

## Acceptance Criteria  
*These must be checked off before this task is considered done.* 
- [ ] ผู้ดูแลระบบสามารถเพิ่มรายการสินค้าใหม่และราคาสินค้าลงในระบบได้ (บันทึกเข้า D2 ข้อมูลสินค้า)
- [ ] ผู้ดูแลระบบสามารถปรับปรุงจำนวนสต็อกสินค้า (เพิ่มสต็อก / ลดสต็อก) ได้อย่างถูกต้อง
- [ ] ผู้ดูแลระบบสามารถบันทึกและจัดการข้อมูลหมวดหมู่สินค้าได้ (บันทึกเข้า D3 ข้อมูลหมวดหมู่)
- [ ] ผู้ดูแลระบบสามารถบันทึกและจัดการข้อมูลแบนเนอร์ประชาสัมพันธ์ได้ (บันทึกเข้า D4 ข้อมูลแบนเนอร์)
- [ ] ระบบมีการแสดงผลข้อความแจ้งเตือนสถานะการบันทึกข้อมูลสำเร็จหรือล้มเหลวให้แก่ผู้ดูแลระบบทราบ
- [ ] UI matches the Figma design (Link here: )  

## Technical Specifications (SAs to fill out)  
* **Target Next.js Route/Component:** `/pages/admin/products/...`, `/pages/admin/categories/...`, `/pages/admin/banners/...` หรือ `components/admin/...` 
* **API Endpoint Required:** 
  * `POST /api/admin/products` (เพิ่มสินค้าและราคา)
  * `PATCH /api/admin/products/stock` (เพิ่ม/ลดสต็อก)
  * `POST /api/admin/categories` (จัดการหมวดหมู่)
  * `POST /api/admin/banners` (จัดการแบนเนอร์)
* **MySQL Tables Impacted:** `Products`, `Stocks`, `Categories`, `Banners`  

## Additional Notes  
* 