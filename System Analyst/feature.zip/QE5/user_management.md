---  
name: Feature / Task Request  
about: Create a new feature or development task  
title: '[TASK] ระบบจัดการข้อมูลผู้ใช้งาน (User Management System)'  
labels: 'enhancement'  
assignees: ''  
---  

## User Story  
**As a** Customer / Admin  
**I want to** สามารถเข้าสู่ระบบ สมัครสมาชิก และจัดการข้อมูลส่วนตัว (แก้ไขโปรไฟล์/ที่อยู่จัดส่ง) ได้ผ่านระบบจัดการข้อมูลผู้ใช้งาน  
**So that** เพื่อให้สามารถเข้าใช้งานระบบได้อย่างปลอดภัย และมีข้อมูลที่ถูกต้องสำหรับการจัดส่งสินค้าและติดต่อสื่อสาร  

## Acceptance Criteria  
*These must be checked off before this task is considered done.* 
- [ ] ลูกค้าและผู้ดูแลระบบสามารถเข้าสู่ระบบ (Login) ด้วยข้อมูลล็อกอินที่ถูกต้อง และระบบแสดงผลการล็อกอินสำเร็จ/ล้มเหลวอย่างถูกต้อง
- [ ] ลูกค้าใหม่สามารถสมัครสมาชิก (Register) โดยระบบจะทำการบันทึกข้อมูลสมาชิกลงในฐานข้อมูล (D1 ข้อมูลสมาชิก)
- [ ] ลูกค้าสามารถเรียกดูและแก้ไขข้อมูลโปรไฟล์ส่วนตัว (Edit Profile) รวมถึงข้อมูลที่อยู่จัดส่ง (Shipping Address) ได้
- [ ] UI matches the Figma design (Link here: )  

## Technical Specifications (SAs to fill out)  
* **Target Next.js Route/Component:** `/pages/auth/...`, `/pages/profile/...`, `components/user/...`
* **API Endpoint Required:** 
  * `POST /api/auth/login`
  * `POST /api/auth/register`
  * `GET /api/user/profile`
  * `PUT /api/user/profile`
  * `PUT /api/user/address`
* **MySQL Tables Impacted:** `Users` / `Members`, `Addresses`  

## Additional Notes  
* 