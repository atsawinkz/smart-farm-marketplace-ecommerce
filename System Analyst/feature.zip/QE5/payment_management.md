---  
name: Feature / Task Request  
about: Create a new feature or development task  
title: '[TASK] ระบบจัดการการชำระเงิน (Payment Management System)'  
labels: 'enhancement'  
assignees: ''  
---  

## User Story  
**As a** Customer  
**I want to** สามารถชำระเงินค่ายืนยันคำสั่งซื้อผ่านระบบชำระเงินภายนอก และได้รับใบเสร็จรับเงินเมื่อชำระเงินสำเร็จ  
**So that** เพื่อให้กระบวนการสั่งซื้อสินค้าเสร็จสมบูรณ์อย่างถูกต้อง และมีหลักฐานการชำระเงินเก็บไว้ตรวจสอบ  

## Acceptance Criteria  
*These must be checked off before this task is considered done.* 
- [ ] ระบบสามารถดึง "ข้อมูลยอดเงินที่ต้องชำระ" จากฐานข้อมูลคำสั่งซื้อ (D6 ข้อมูลคำสั่งซื้อ) มาแสดงผลให้แก่ลูกค้าและส่งต่อให้ระบบชำระเงินได้ถูกต้อง
- [ ] ลูกค้าสามารถส่งข้อมูลการชำระเงิน (ชำระเงิน) และระบบสามารถส่งข้อมูลยอดการชำระเงินไปยังระบบชำระเงิน (Payment Gateway) ได้
- [ ] ระบบสามารถรับข้อมูลสถานะการชำระเงินจากระบบชำระเงินภายนอก เพื่อนำมา "อัปเดตสถานะการชำระเงิน" กลับไปยังฐานข้อมูล (D6 ข้อมูลคำสั่งซื้อ)
- [ ] เมื่ออัปเดตสถานะชำระเงินสำเร็จ ระบบจะต้องออกและแสดงผล "ใบเสร็จชำระเงิน" ให้แก่ลูกค้าทราบ
- [ ] UI matches the Figma design (Link here: )  

## Technical Specifications (SAs to fill out)  
* **Target Next.js Route/Component:** `/pages/checkout/payment/...`, `/components/payment/...` หรือ `/pages/payment/success/...`
* **API Endpoint Required:** 
  * `GET /api/payment/amount` (ดึงยอดเงินที่ต้องชำระตามเลขออร์เดอร์)
  * `POST /api/payment/checkout` (ส่งข้อมูลไปยัง Payment Gateway)
  * `POST /api/payment/webhook` (รับ callback/ข้อมูลสถานะจากระบบชำระเงินเพื่ออัปเดตฐานข้อมูล)
* **MySQL Tables Impacted:** `Orders` (ตารางคำสั่งซื้อที่ผูกกับ D6), `Payments` / `Invoices`

## Additional Notes  
* 