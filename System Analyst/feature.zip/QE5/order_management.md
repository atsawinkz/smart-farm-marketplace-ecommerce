---  
name: Feature / Task Request  
about: Create a new feature or development task  
title: '[TASK] ระบบจัดการคำสั่งซื้อ (Order Management System)'  
labels: 'enhancement'  
assignees: ''  
---  

## User Story  
**As a** Customer / Admin  
**I want to** สามารถหยิบสินค้าใส่ตะกร้า ยืนยันคำสั่งซื้อ และอัปเดตสถานะของคำสั่งซื้อได้  
**So that** ลูกค้าสามารถสั่งซื้อสินค้าที่ต้องการได้อย่างถูกต้อง และผู้ดูแลระบบสามารถรับรู้รวมถึงอัปเดตสถานะการสั่งซื้อได้อย่างมีประสิทธิภาพ  

## Acceptance Criteria  
*These must be checked off before this task is considered done.* 
- [ ] ลูกค้าสามารถหยิบสินค้าใส่ตะกร้าได้ โดยระบบจะทำการบันทึกข้อมูลสินค้าที่เพิ่มลงตะกร้า (D5 ข้อมูลการหยิบใส่ตะกร้า) และดึงรายการสินค้าในตะกร้ามาแสดงผลได้ถูกต้อง
- [ ] ลูกค้าสามารถยืนยันคำสั่งซื้อได้ โดยระบบจะทำการดึงข้อมูลที่อยู่ (D1 ข้อมูลสมาชิก) ข้อมูลรายการสินค้า (D2 ข้อมูลสินค้า) แล้วสรุปรายการคำสั่งซื้อให้ลูกค้า พร้อมบันทึกคำสั่งซื้อ (D6 ข้อมูลคำสั่งซื้อ)
- [ ] ระบบสามารถแจ้งเตือนออร์เดอร์ใหม่ไปยังผู้ดูแลระบบได้ทันทีเมื่อมีคำสั่งซื้อเข้ามา
- [ ] ผู้ดูแลระบบสามารถอัปเดตสถานะคำสั่งซื้อ (ข้อมูลอัปเดตสถานะสั่งซื้อ) เพื่อบันทึกการเปลี่ยนแปลงลงในระบบ (D6 ข้อมูลคำสั่งซื้อ) ได้
- [ ] UI matches the Figma design (Link here: )  

## Technical Specifications (SAs to fill out)  
* **Target Next.js Route/Component:** `/pages/cart/...`, `/pages/checkout/...`, `/pages/admin/orders/...` หรือ `components/orders/...`
* **API Endpoint Required:** 
  * `POST /api/cart/add` (หยิบสินค้าใส่ตะกร้า)
  * `GET /api/cart` (ดูรายการสินค้าในตะกร้า)
  * `POST /api/orders/checkout` (ยืนยันและบันทึกคำสั่งซื้อ)
  * `PATCH /api/admin/orders/status` (ผู้ดูแลระบบอัปเดตสถานะสั่งซื้อ)
* **MySQL Tables Impacted:** `Members`, `Products`, `Cart_Items`, `Orders`, `Order_Items`  

## Additional Notes  
* 