---  
name: Feature / Task Request  
about: Create a new feature or development task  
title: '[TASK] ระบบจัดการการจัดส่ง (Shipping & Delivery Management)'  
labels: 'enhancement'  
assignees: ''  
---  

## User Story  
**As a** Customer / System  
**I want to** สามารถติดตามสถานะการจัดส่งพัสดุ อัปเดตสถานะการจัดส่ง และกดยืนยันการได้รับสินค้าได้  
**So that** ลูกค้าทราบความคืบหน้าของการจัดส่งพัสดุ และระบบสามารถปิดยอดคำสั่งซื้อได้อย่างสมบูรณ์เมื่อสินค้าถึงมือผู้รับ  

## Acceptance Criteria  
*These must be checked off before this task is considered done.* 
- [ ] ระบบสามารถดึงข้อมูลที่อยู่ (จาก D1 ข้อมูลสมาชิก) และข้อมูลคำสั่งซื้อ (จาก D6 ข้อมูลคำสั่งซื้อ) มาใช้จัดเตรียมการจัดส่งได้อย่างถูกต้อง
- [ ] ระบบสามารถรับข้อมูลอัปเดตสถานะการจัดส่ง (จากเจ้าหน้าที่จัดส่ง/ระบบขนส่งภายนอก) เพื่อนำไป "อัปเดตสถานะ" กลับไปยังฐานข้อมูลคำสั่งซื้อ (D6 ข้อมูลคำสั่งซื้อ)
- [ ] ระบบสามารถส่งการแจ้งเตือนสถานะการจัดส่งพัสดุ ไปยังลูกค้าได้เมื่อมีการเปลี่ยนแปลงสถานะ
- [ ] ลูกค้าสามารถกดยืนยันได้รับสินค้าสำเร็จ (ยืนยันได้รับสินค้าสำเร็จ) เพื่ออัปเดตสถานะในระบบให้เสร็จสิ้น
- [ ] UI matches the Figma design (Link here: )  

## Technical Specifications (SAs to fill out)  
* **Target Next.js Route/Component:** `/pages/tracking/...`, `/pages/admin/shipping/...` หรือ `components/shipping/...`  
* **API Endpoint Required:**   
  * `GET /api/shipping/tracking/:orderId` (ดึงข้อมูลสถานะการจัดส่งและที่อยู่)
  * `POST /api/shipping/update-status` (อัปเดตสถานะการจัดส่งพัสดุ)
  * `POST /api/shipping/confirm-delivery` (ลูกค้ายืนยันได้รับสินค้า)
* **MySQL Tables Impacted:** `Members` (D1), `Orders` (D6), `Shipping_Tracking`  

## Additional Notes  
* 