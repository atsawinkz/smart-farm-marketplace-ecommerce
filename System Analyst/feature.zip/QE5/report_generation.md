---  
name: Feature / Task Request  
about: Create a new feature or development task  
title: '[TASK] ระบบออกรายงานสรุปยอดขาย (Sales Reporting System)'  
labels: 'enhancement'  
assignees: ''  
---  

## User Story  
**As an** Admin  
**I want to** สามารถส่งคำขอเรียกดูรายงานสรุปยอดขายของระบบได้  
**So that** เพื่อให้สามารถนำรายงานสรุปยอดขายไปวิเคราะห์ วางแผนการตลาด และติดตามผลการดำเนินงานของธุรกิจได้อย่างถูกต้อง  

## Acceptance Criteria  
*These must be checked off before this task is considered done.* 
- [ ] ผู้ดูแลระบบสามารถส่ง "คำขอเรียกดูรายงาน" ผ่านหน้าต่างระบบจัดการได้
- [ ] ระบบสามารถดึง "ข้อมูลคำสั่งซื้อ" จากฐานข้อมูลคำสั่งซื้อ (D6 ข้อมูลคำสั่งซื้อ) มารวบรวมประมวลผลได้ถูกต้อง
- [ ] ระบบสามารถดึง "ข้อมูลสินค้า" จากฐานข้อมูลสินค้า (D2 ข้อมูลสินค้า) มาประกอบรายงานเพื่อแจกแจงรายละเอียดสินค้าได้ถูกต้อง
- [ ] ระบบสามารถประมวลผลและแสดงผล "รายงานสรุปยอดขาย" ส่งกลับไปให้ผู้ดูแลระบบดูบนหน้าเว็บไซต์หรือดาวน์โหลดได้
- [ ] UI matches the Figma design (Link here: )  

## Technical Specifications (SAs to fill out)  
* **Target Next.js Route/Component:** `/pages/admin/reports/...` หรือ `components/admin/DashboardReport/...`
* **API Endpoint Required:** `GET /api/admin/reports/sales-summary`  
* **MySQL Tables Impacted:** `Orders` (D6), `Order_Items` (D6), `Products` (D2)  

## Additional Notes  
* 